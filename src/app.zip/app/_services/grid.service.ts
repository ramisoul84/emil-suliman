import { Injectable, NgZone } from "@angular/core";
import { BehaviorSubject } from "rxjs";

const breakpoints = [
    { minWidth: 2160, gridCount: 87 },
    { minWidth: 1560, gridCount: 77 },
    { minWidth: 1160, gridCount: 67 },
    { minWidth: 536, gridCount: 37 },
    { minWidth: 0, gridCount: 27 }
];

@Injectable({
    providedIn: 'root'
})
export class GridService {
    private gridWidthSubject = new BehaviorSubject<number>(this.getGridWidth());
    public gridWidth$ = this.gridWidthSubject.asObservable();
    private resizeTimeout: any = null;

    constructor(private ngZone: NgZone) {
        this.initializeGrid();
    }

    private initializeGrid(): void {
        this.updateGrid();
        this.ngZone.runOutsideAngular(() => {
            window.addEventListener('resize', () => this.updateGrid());
            window.addEventListener('orientationchange', () => this.updateGrid());
            if (window.visualViewport) {
                window.visualViewport.addEventListener('resize', () => this.updateGrid());
            }
        });
    }

    getGridWidth(): number {
        const width = this.getAccurateWidth();
        const gridCount = this.getGridCount(width);
        return width / gridCount;
    }

    getMaxHeight(delta: number): number {
        const screenHeight = window.innerHeight;
        const width = this.gridWidthSubject.value;
        const n = Math.floor(screenHeight / width) - delta;
        return n * width;
    }

    private updateGrid(): void {
        this.ngZone.run(() => {
            let width = this.getAccurateWidth() - 20;
            const gridCount = this.getGridCount(width);
            const gridSize = Math.floor(width / gridCount);
            const totalGridWidth = gridSize * gridCount;
            const extraSpace = width - totalGridWidth;
            const margin = 10 + (extraSpace - 1) / 2;

            this.gridWidthSubject.next(gridSize);

            document.documentElement.style.setProperty('--dynamic-grid-size', `${gridSize}px`);
            document.documentElement.style.setProperty('--margin', `${margin}px`);
        });
    }

    ngOnDestroy(): void {
        if (this.resizeTimeout) {
            clearTimeout(this.resizeTimeout);
        }
    }

    private getAccurateWidth(): number {
        return document.documentElement.clientWidth;
    }

    private getGridCount(width: number): number {
        const breakpoint = breakpoints.find(bp => width >= bp.minWidth);
        return breakpoint?.gridCount || 20;
    }
}
